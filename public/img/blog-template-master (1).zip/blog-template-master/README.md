# Blog Template

This is a blog template I've made as a graduation project for front-end deploma I took with [IT Sharks](https://www.facebook.com/ITSharks24)

I made it using React js & Bootstrap

You can check it on live demo [here](https://blog-template-vert-six.vercel.app/)
